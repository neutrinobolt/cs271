source: https://www.nand2tetris.org/copy-of-talks

There are a list of neat talks, games, and other thoughts related to materials in the course!